public interface IImprimir {
    public void imprimir();
}